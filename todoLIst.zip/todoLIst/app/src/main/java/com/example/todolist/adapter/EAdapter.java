package com.example.todolist.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.todolist.R;
import com.example.todolist.entity.Event;
import com.example.todolist.entity.EventData;

import java.util.ArrayList;
import java.util.List;

public class EAdapter extends BaseAdapter {
    private List<Event> eventList;
    private List<EventData> eventDataList;
    private LayoutInflater inflater;
    private Event event;

    public EAdapter(List<EventData> list, Context context){

        this.eventDataList = list;
        inflater = LayoutInflater.from(context);
    }


    @Override
    public int getCount() {
        return eventDataList.size();
    }

    @Override
    public Object getItem(int i) {
        return eventDataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if(convertView == null){
            convertView = inflater.inflate(R.layout.event_item, null);
            viewHolder = new ViewHolder();
            viewHolder.date = (TextView)convertView.findViewById(R.id.date);
            viewHolder.title = (TextView)convertView.findViewById(R.id.title);
            viewHolder.condition = convertView.findViewById(R.id.condition);
            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder)convertView.getTag();
        }

        EventData data = eventDataList.get(position);
        String dateText = data.getHour()+"";
        String timeText = data.getMinuet()+"";
        if(data.getHour() < 10){
            dateText = "0"+dateText;
        }
        if(data.getMinuet() < 10){
            timeText = "0"+timeText;
        }

        viewHolder.date.setText(dateText+":"+timeText);
        viewHolder.title.setText(data.getTitle());

        if(eventDataList.get(position).getFinished().equals("0")) {
            viewHolder.condition.setBackgroundResource(R.color.none);
        }else if(eventDataList.get(position).getFinished().equals("1")) {
            viewHolder.condition.setBackgroundResource(R.color.positive);
        }else {
            viewHolder.condition.setBackgroundResource(R.color.negative);
        }
        return convertView;

    }

    class ViewHolder{
        TextView date;
        TextView title;
        View condition;
    }
}
