package com.example.todolist.entity;

public class Event {

    private String Date;

    private String eventTile;

    private int condition;

    public Event() {
    }

    public Event(String date, String eventTile) {
        Date = date;
        this.eventTile = eventTile;
    }

    public Event(String date, String eventTile, int condition) {
        Date = date;
        this.eventTile = eventTile;
        this.condition = condition;
    }

    public int getCondition() {
        return condition;
    }

    public void setCondition(int condition) {
        this.condition = condition;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getEventTile() {
        return eventTile;
    }

    public void setEventTile(String eventTile) {
        this.eventTile = eventTile;
    }
}
