package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.todolist.adapter.EAdapter;
import com.example.todolist.dataBase.MDataBase;
import com.example.todolist.entity.Event;
import com.example.todolist.entity.EventData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.CalendarView;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    private FloatingActionButton add_item;
    private FloatingActionButton goto_today;

    private ListView list;

    private TextView todayText;

    private CalendarView mCalenderView;

    private MDataBase  mDataBase;
    private SQLiteDatabase db;

    private List<EventData> eventDataList;
    private EAdapter adapter;

    private int selectedYear;
    private int selectedMonth;
    private int selectedDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        updateLocale();

        mCalenderView = findViewById(R.id.Calender2);

        todayText = findViewById(R.id.today);

        add_item = findViewById(R.id.add_item);
        goto_today = findViewById(R.id.goto_today);

        list = findViewById(R.id.list);

        mDataBase = new MDataBase(this,1);

        todayText.setText(mCalenderView.getCurYear()+"年"+mCalenderView.getCurMonth()+"月"+mCalenderView.getCurDay()+"日");


        initEventList();
        initAllData();
        setSchemeDate();
        initFloatButton();

        /*Map<String, Calendar> map=new HashMap<>();
        map.put(getSchemeCalendar(2022, 5, 22, 0xFF40db25, "").toString(),
                getSchemeCalendar(2022,5, 22, 0xFF40db25, ""));
        map.put(getSchemeCalendar(2022, 5, 21, 0xFF40db25, "").toString(),
                getSchemeCalendar(2022,5, 21, 0xFF40db25, ""));
        map.put(getSchemeCalendar(2022, 5, 20, 0xFF40db25, "").toString(),
                getSchemeCalendar(2022,5, 20, 0xFF40db25, ""));

        mCalenderView.setSchemeDate(map);*/


        mCalenderView.setOnCalendarSelectListener(new CalendarView.OnCalendarSelectListener() {
            @Override
            public void onCalendarOutOfRange(Calendar calendar) {

            }

            @Override
            public void onCalendarSelect(Calendar calendar, boolean isClick) {
                if(calendar.getYear() != mCalenderView.getCurYear() || calendar.getMonth() != mCalenderView.getCurMonth() || calendar.getDay() != mCalenderView.getCurDay()){
                    goto_today.setVisibility(View.VISIBLE);
                }else {
                    goto_today.setVisibility(View.INVISIBLE);
                }
                String date = calendar.getYear()+"年"+calendar.getMonth()+"月"+calendar.getDay()+"日";
                todayText.setText(date);

                initEventData(calendar.getYear(),calendar.getMonth(),calendar.getDay());
                adapter = new EAdapter(eventDataList,MainActivity.this);
                list.setAdapter(adapter);


            }
        });


    }

    //初始化悬浮按钮
    private void initFloatButton() {
        add_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"添加事件",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,EditActivity.class);
                startActivity(intent);
            }
        });

        //回到今天悬浮按钮
        goto_today.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCalenderView.scrollToCalendar(mCalenderView.getCurYear(),mCalenderView.getCurMonth(),mCalenderView.getCurDay());
            }
        });
    }

    //标记有事件的日期
    @SuppressLint("Range")
    private void setSchemeDate() {
        Map<String, Calendar> map=new HashMap<>();

        db = mDataBase.getReadableDatabase();
        //查找有事件的日期
        Cursor cursor = db.rawQuery("select year,month,day from " +
                "event group by year,month,day ", null);
        cursor.moveToFirst();

        while (!cursor.isAfterLast()){
            Calendar schemeCalendar = getSchemeCalendar(cursor.
                            getInt(cursor.getColumnIndex("year")),
                    cursor.getInt(cursor.getColumnIndex("month")),
                    cursor.getInt(cursor.getColumnIndex("day")));
            //存储日期数据
            map.put(schemeCalendar.toString(),schemeCalendar);
            cursor.moveToNext();
        }
        cursor.close();
        //有事件的日期标记
       mCalenderView.setSchemeDate(map);
    }

    // 处理已过期的数据
    @SuppressLint("Range")
    private void initAllData() {
        int curYear = mCalenderView.getCurYear();
        int curMonth = mCalenderView.getCurMonth();
        int curDay = mCalenderView.getCurDay();
        LocalDateTime now = LocalDateTime.now();
        int curHour = now.getHour();
        int curMinute = now.getMinute();


        db = mDataBase.getReadableDatabase();

        Cursor cursor = db.rawQuery("select * from event where year <=? and finished = ? ", new String[]{curYear + "", "0"});
        cursor.moveToFirst();

        db = mDataBase.getWritableDatabase();

        while (!cursor.isAfterLast()){
            int id = cursor.getInt(cursor.getColumnIndex("id"));
            int year = cursor.getInt(cursor.getColumnIndex("year"));
            int month = cursor.getInt(cursor.getColumnIndex("month"));
            int day = cursor.getInt(cursor.getColumnIndex("day"));
            int hour = cursor.getInt(cursor.getColumnIndex("hour"));
            int minute = cursor.getInt(cursor.getColumnIndex("minute"));

            if(year < curYear){
                changeEventStatus(db,id,year,month,day);
            }else if(year == curYear){
                if(month < curMonth){
                    changeEventStatus(db,id,year,month,day);
                }else if(month == curMonth){
                    if(day < curDay){
                        changeEventStatus(db,id,year,month,day);
                    }else if(day == curDay){
                        if(hour < curHour){
                            changeEventStatus(db,id,year,month,day);
                        }else if(hour == curHour){
                            if(minute < curMinute){
                                changeEventStatus(db,id,year,month,day);
                            }
                        }
                    }
                }
            }


            cursor.moveToNext();
        }

        cursor.close();

    }

    @SuppressLint("Range")
    private void changeEventStatus(SQLiteDatabase db, int id, int year, int month, int day) {

        ContentValues values = new ContentValues();
        values.put("finished", "2");
        db.update("event", values, "id=?", new String[]{id + ""});
        Cursor cursor = db.rawQuery("select * from acount where year = ? and month = ? and day = ?", new String[]{year + "", month + "", day + ""});
        cursor.moveToFirst();
        if(cursor.isAfterLast()){
            values.clear();
            values.put("year",year);
            values.put("month",month);
            values.put("day",day);
            values.put("overdue",1);
            db.insert("acount",null,values);
        }else {
            values.clear();
            values.put("overdue",cursor.getInt(cursor.getColumnIndex("overdue"))+1);
            values.put("unfinish",cursor.getInt(cursor.getColumnIndex("unfinish")) - 1);
            @SuppressLint("Range") int aId = cursor.getInt(cursor.getColumnIndex("id"));
            db.update("acount",values,"id = ?",new String[]{aId+""});
        }
        /*values.clear();
        values.put("unfinish",0);
        db.update("acount",values,"id = ?",new String[]{"6"});*/

        cursor.close();
    }

    // 初始化当天数据
    private void initEventList() {
        initEventData(mCalenderView.getCurYear(),mCalenderView.getCurMonth(),mCalenderView.getCurDay());
        adapter = new EAdapter(eventDataList,MainActivity.this);
        list.setAdapter(adapter);

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                EventData eventData = eventDataList.get(i);
                Toast.makeText(MainActivity.this, "长按了"+eventData.getId(), Toast.LENGTH_SHORT).show();
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("是否删除该事项？").setTitle("提示").setIcon(R.drawable.ic_baseline_warning_24_yellow)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                db = mDataBase.getWritableDatabase();
                                int row = db.delete("event", "id=?", new String[]{"" + eventData.getId()});
                                if(row > 0){
                                    Toast.makeText(MainActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                                    eventDataList.remove(eventData);
                                    adapter.notifyDataSetChanged();
                                }else {
                                    Toast.makeText(MainActivity.this, "删除失败", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        }).show();

                return true;
            }
        });

    }

    // 重新加载数据
    @Override
    protected void onRestart() {
        super.onRestart();

        setSchemeDate();
        initAllData();

        initEventData(mCalenderView.getCurYear(),mCalenderView.getCurMonth(),mCalenderView.getCurDay());
        mCalenderView.scrollToCalendar(mCalenderView.getCurYear(),mCalenderView.getCurMonth(),mCalenderView.getCurDay());
        adapter = new EAdapter(eventDataList,MainActivity.this);
        list.setAdapter(adapter);
    }

    @SuppressLint("Range")
    private void initEventData(int year,int month,int day) {
        eventDataList = new ArrayList<>();
        db = mDataBase.getReadableDatabase();

//        Cursor cursor = db.query("event", null, null,null, null, null, null);
        Cursor cursor = db.rawQuery("select * from event where year = ? and month = ? and day = ? ",new String[]{""+year,""+month,""+day});
//        @SuppressLint("DefaultLocale") String sql = String.format("select * from event where year = %d and month = %d and day = %d" ,year,month,day);
//        Cursor cursor = db.rawQuery(sql,null);

        cursor.moveToFirst();

        while (!cursor.isAfterLast()){
            EventData eventData = new EventData(cursor.getInt(cursor.getColumnIndex("id")),
                    cursor.getInt(cursor.getColumnIndex("year")),
                    cursor.getInt(cursor.getColumnIndex("month")),
                    cursor.getInt(cursor.getColumnIndex("day")),
                    cursor.getInt(cursor.getColumnIndex("hour")),
                    cursor.getInt(cursor.getColumnIndex("minute")),
                    cursor.getString(cursor.getColumnIndex("title")),
                    cursor.getString(cursor.getColumnIndex("content")),
                    cursor.getString(cursor.getColumnIndex("finished")),
                    cursor.getString(cursor.getColumnIndex("imgUri")));
            eventDataList.add(eventData);
            cursor.moveToNext();
        }

        cursor.close();

    }

    private Calendar getSchemeCalendar(int year, int month, int day) {
        Calendar calendar = new Calendar();
        calendar.setYear(year);
        calendar.setMonth(month);
        calendar.setDay(day);
//        calendar.setSchemeColor(color);//如果单独标记颜色、则会使用这个颜色
//        calendar.setScheme(text);
        return calendar;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_option,menu);

        return true;
    }

    /**
     * 菜单项目点击事件
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId(); //获取菜单项id
        Intent intent;
        switch (itemId){
            case R.id.menu_change:
                Toast.makeText(this,"切换视图",Toast.LENGTH_SHORT).show();
                intent = new Intent(this, ListActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_statistic:
                Toast.makeText(this,"统计",Toast.LENGTH_SHORT).show();
                intent = new Intent(this, AccountActivity.class);
                startActivity(intent);
                return true;
        }
        return true;
    }

    private void updateLocale() {
        try {
            Locale locale = getResources().getConfiguration().locale;
            if (locale == Locale.SIMPLIFIED_CHINESE) {  //常量比较
                return;
            }
            Resources resources = getResources();
            Configuration configuration = resources.getConfiguration();
            Locale.setDefault(Locale.SIMPLIFIED_CHINESE);
            if (Build.VERSION.SDK_INT >= 24) {
                configuration.setLocales(new LocaleList(Locale.SIMPLIFIED_CHINESE));
            } else if (Build.VERSION.SDK_INT >= 17) {
                configuration.setLocale(Locale.SIMPLIFIED_CHINESE);
            } else {
                configuration.locale = Locale.SIMPLIFIED_CHINESE;
            }
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }



}