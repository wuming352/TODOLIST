package com.example.todolist.entity;

public class Account {
    private int id;
    private int year;
    private int month;
    private int day;
    private int finish;
    private int overdue;
    private int cancel;

    public Account() {
    }

    public Account(int id, int year, int month, int day, int finish, int overdue, int cancel) {
        this.id = id;
        this.year = year;
        this.month = month;
        this.day = day;
        this.finish = finish;
        this.overdue = overdue;
        this.cancel = cancel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getFinish() {
        return finish;
    }

    public void setFinish(int finish) {
        this.finish = finish;
    }

    public int getOverdue() {
        return overdue;
    }

    public void setOverdue(int overdue) {
        this.overdue = overdue;
    }

    public int getCancel() {
        return cancel;
    }

    public void setCancel(int cancel) {
        this.cancel = cancel;
    }
}
