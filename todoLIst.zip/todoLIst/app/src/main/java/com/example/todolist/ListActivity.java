package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.todolist.adapter.EListAdapter;
import com.example.todolist.dataBase.MDataBase;
import com.example.todolist.entity.EventData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity implements EListAdapter.MClickListener, EListAdapter.MLongClickListener, EListAdapter.DetailClickListener {

    private ListView event_list;
    private List<EventData> eventDataList;
    private EListAdapter eListAdapter;

    private FloatingActionButton add_btn;

    private MDataBase mDataBase;
    private SQLiteDatabase db;

    private PopupWindow detailWindow;
    private String URI = "/storage/emulated/0/Android/data/com.example.todolist/cache/";
    private Uri imgUri;                 // 相片Uri


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        event_list = findViewById(R.id.event_list);
        mDataBase = new MDataBase(this,1);



        initEvenDataList();
        initList();

        add_btn = findViewById(R.id.add_btn);
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ListActivity.this,EditActivity.class);
                startActivity(intent);
            }
        });

    }

    private void initList() {
        eListAdapter = new EListAdapter(eventDataList,this,this,this,this);
        event_list.setAdapter(eListAdapter);

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        initEvenDataList();
        initList();
    }

    @Override
    public void clickListener(View view) {
        Toast.makeText(this, "点击删除", Toast.LENGTH_SHORT).show();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_baseline_warning_24_yellow).setTitle("提示").setMessage("是否删除改事项")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @SuppressLint("Range")
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(ListActivity.this, "确定", Toast.LENGTH_SHORT).show();

                        int tag = (int) view.getTag();
                        int id = eventDataList.get(tag).getId();
                        int year = eventDataList.get(tag).getYear();
                        int month = eventDataList.get(tag).getMonth();
                        int day = eventDataList.get(tag).getDay();
                        String finished = eventDataList.get(tag).getFinished();

                        db = mDataBase.getWritableDatabase();
                        int row = db.delete("event", "id=?", new String[]{id + ""});
                        if(row > 0){
                            Toast.makeText(ListActivity.this, "删除成功", Toast.LENGTH_SHORT).show();

                            ContentValues values = new ContentValues();
                            db = mDataBase.getReadableDatabase();
                            Cursor cursor = db.rawQuery("select * from acount where year = ? and month = ? and day = ?", new String[]{year + "", month + "", day + ""});
                            cursor.moveToFirst();
                            if(cursor.isAfterLast()){
                                values.clear();
                                values.put("year",year);
                                values.put("month",month);
                                values.put("day",day);
                                values.put("cancel",1);

                                if(finished.equals("0") || finished.equals("1")){
                                    db.insert("acount",null,values);
                                }

                            }else {
                                values.clear();
                                @SuppressLint("Range") int aId = cursor.getInt(cursor.getColumnIndex("id"));
                                if(finished.equals("0")){
                                    values.put("cancel",cursor.getInt(cursor.getColumnIndex("cancel")) + 1);
                                    values.put("unfinish",cursor.getInt(cursor.getColumnIndex("unfinish")) - 1);
                                    db.update("acount",values,"id = ?",new String[]{aId+""});
                                }
                               /*else if(finished.equals("1")){
                                    values.put("finish",cursor.getInt(cursor.getColumnIndex("finish")) - 1);
                                    db.update("acount",values,"id = ?",new String[]{aId+""});
                                }*/

                            }
                            cursor.close();

                            eventDataList.remove(tag);
                            eListAdapter.notifyDataSetChanged();
                            initList();
                        }else {
                            Toast.makeText(ListActivity.this, "删除失败", Toast.LENGTH_SHORT).show();
                        }

                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(ListActivity.this, "取消", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }

    @Override
    public void longClickListener(View view) {
        int tag = (int) view.getTag();
        int id = eventDataList.get(tag).getId();
        Intent intent = new Intent(this, EditActivity.class);
        intent.putExtra("id",id);

        Toast.makeText(this, "编辑事项："+tag, Toast.LENGTH_SHORT).show();

        startActivity(intent);

    }

    @Override
    public void detailClickListener(View view) {
        View v = getLayoutInflater().inflate(R.layout.event_detail, null);

        TextView detailContent = v.findViewById(R.id.detail_content);
        ImageView detail_img = v.findViewById(R.id.detail_img);

        int tag = (int) view.getTag();
//        Toast.makeText(this, tag+"", Toast.LENGTH_SHORT).show();
        EventData eventData = eventDataList.get(tag);
        String imgName = eventData.getImgUri();
        detailContent.setText(eventData.getContent());

        if(!eventData.getImgUri().equals("")) {
            File testFile = new File(URI + imgName);
            imgUri = FileProvider.getUriForFile(this, "com.todolist.fileProvider", testFile);
            try {
                InputStream inputStream = getContentResolver().openInputStream(imgUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                detail_img.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        detailWindow = new PopupWindow(v,800, ViewGroup.LayoutParams.WRAP_CONTENT);
        detailWindow.setOutsideTouchable(true);
        detailWindow.setFocusable(true);
        detailWindow.showAtLocation(event_list, Gravity.CENTER,0,0);

    }

    private void initEvenDataList() {
        eventDataList = new ArrayList<>();
        db = mDataBase.getReadableDatabase();

        Cursor cursor = db.query("event", null, null, null, null, null, null);
        cursor.moveToFirst();

        while (!cursor.isAfterLast()){
            @SuppressLint("Range") EventData eventData = new EventData(cursor.getInt(cursor.getColumnIndex("id")),
                    cursor.getInt(cursor.getColumnIndex("year")),
                    cursor.getInt(cursor.getColumnIndex("month")),
                    cursor.getInt(cursor.getColumnIndex("day")),
                    cursor.getInt(cursor.getColumnIndex("hour")),
                    cursor.getInt(cursor.getColumnIndex("minute")),
                    cursor.getString(cursor.getColumnIndex("title")),
                    cursor.getString(cursor.getColumnIndex("content")),
                    cursor.getString(cursor.getColumnIndex("finished")),
                    cursor.getString(cursor.getColumnIndex("imgUri")));
            eventDataList.add(eventData);
            cursor.moveToNext();
        }

        cursor.close();

    }

    /**
     * 创建菜单
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_option,menu);

        return true;
    }

    /**
     * 菜单项目点击事件
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId(); //获取菜单项id

        switch (itemId){
            case R.id.menu_change:
                Toast.makeText(this,"切换视图",Toast.LENGTH_SHORT).show();
                finish();
                return true;
            case R.id.menu_statistic:
                Toast.makeText(this,"统计",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, AccountActivity.class);
                startActivity(intent);
                return true;
        }

        return true;
    }



}