package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.todolist.dataBase.MDataBase;
import com.example.todolist.entity.EventData;
import com.example.todolist.utils.ImageUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class EditActivity extends AppCompatActivity {

    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;

    private int selectedYear;
    private int selectedMonth;
    private int selectedDay;

    private ImageButton timePickerBtn;  // 时间选择按钮
    private TextView event_time;        // 时间展示文本
    private EditText event_title;       // 事件标题
    private EditText event_content;     // 事件内容

    private PopupWindow timePickWindow; // 时间选择弹窗

    private Button editBtn;             // 编辑确定按钮
    private Button cancelBtn;           // 取消返回按钮

    private ImageButton event_photo_btn;// 照相按钮
    private Uri imgUri;                 // 相片Uri

    private ImageView event_img;        // 相片展示
    private String imageBase64;         // 图片bitmap转字符串

    private MDataBase mdb;
    private SQLiteDatabase db;

    private TimePicker timePicker;   //时间选则器
    private DatePicker datePicker;   //日期选择器

    private String URI = "/storage/emulated/0/Android/data/com.example.todolist/cache/";
    private String imgName = "";

    private int flag;


    //TODO 进行日期判断，今天之前的日子不能选择
    //TODO 判断当前页面为编辑还是新增
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        updateLocale();

        timePickerBtn = findViewById(R.id.timePicker);
        event_time = findViewById(R.id.event_time);
        event_title = findViewById(R.id.event_title);
        event_content = findViewById(R.id.event_content);

        cancelBtn = findViewById(R.id.cancel);
        editBtn = findViewById(R.id.edit_add);

        event_photo_btn = findViewById(R.id.event_photo_btn);

        event_img = findViewById(R.id.event_img);

        mdb = new MDataBase(this,1);

        flag = getIntent().getIntExtra("id", 0);

        if(flag != 0){
            initActivity();
        }

        // 取消按钮
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        //编辑/添加按钮
        editBtn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(EditActivity.this);


//                Toast.makeText(EditActivity.this, "时间："+event_time.getText().toString(), Toast.LENGTH_SHORT).show();
                if(flag == 0) {
                    if (event_time.getText().toString().length() > 2) {
                        Toast.makeText(EditActivity.this, "时间：" + event_time.getText().toString(), Toast.LENGTH_SHORT).show();
                        if (!event_title.getText().toString().equals("")) {

                            LocalDateTime now = LocalDateTime.now();
                            int nowYear = now.getYear();
                            int nowMonth = now.getMonthValue();
                            int nowDay = now.getDayOfMonth();
                            int nowHour = now.getHour();
                            int nowMinute = now.getMinute();

                            if(year < nowYear){
                                builder.setIcon(R.drawable.ic_baseline_warning_24_yellow).setMessage("日期选择有误").setTitle("提示").show();
                                return;
                            }
                            if(month < nowMonth){
                                builder.setIcon(R.drawable.ic_baseline_warning_24_yellow).setMessage("日期选择有误").setTitle("提示").show();
                                return;
                            } else if( month == nowMonth && day < nowDay){
                                builder.setIcon(R.drawable.ic_baseline_warning_24_yellow).setMessage("日期选择有误").setTitle("提示").show();
                                return;
                            }
                            /*if(hour < nowHour){
                                builder.setIcon(R.drawable.ic_baseline_warning_24_yellow).setMessage("日期选择有误").setTitle("提示").show();
                                return;
                            }
                            if(minute < nowMinute){
                                builder.setIcon(R.drawable.ic_baseline_warning_24_yellow).setMessage("日期选择有误").setTitle("提示").show();
                                return;
                            }*/

                            db = mdb.getWritableDatabase();
                            ContentValues values = new ContentValues();

                            values.put("year", EditActivity.this.year);
                            values.put("month", EditActivity.this.month);
                            values.put("day", day);
                            values.put("hour", EditActivity.this.hour);
                            values.put("minute", EditActivity.this.minute);
                            values.put("title", event_title.getText().toString());
                            values.put("content", event_content.getText().toString());
                            values.put("finished", "0");
                            values.put("imgUri", imgName);

                            long rows = db.insert("event", null, values);
                            if (rows > 0) {
//                            Toast.makeText(EditActivity.this, "添加成功", Toast.LENGTH_SHORT).show();

                                db = mdb.getReadableDatabase();
                                Cursor cursor = db.rawQuery("select * from acount where year = ? and month = ? and day = ?", new String[]{year + "", month + "", day + ""});
                                cursor.moveToFirst();
                                if(cursor.isAfterLast()){
                                    values.clear();
                                    values.put("year",year);
                                    values.put("month",month);
                                    values.put("day",day);
                                    values.put("unfinish",1);

                                    db.insert("acount",null,values);

                                }else {
                                    values.clear();
                                    values.put("unfinish",cursor.getInt(cursor.getColumnIndex("unfinish")) + 1);
                                    int id = cursor.getInt(cursor.getColumnIndex("id"));
                                    db.update("acount",values,"id=?",new String[]{id+""});
                                }
                                cursor.close();


                                builder.setIcon(R.drawable.ic_baseline_check_24)
                                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                finish();
                                            }
                                        }).setMessage("添加成功！").setTitle("提示").show();
                            } else {
//                            Toast.makeText(EditActivity.this, "添加失败", Toast.LENGTH_SHORT).show();
                                builder.setIcon(R.drawable.ic_baseline_warning_24).setMessage("添加失败，请重试！").setTitle("提示").show();
                            }

                        } else {
                            builder.setMessage("请输入标题").setTitle("提示").show();
                        }
                    } else {
                        builder.setMessage("请选择时间").setTitle("提示").show();
                    }
                }else {
                    if (!event_title.getText().toString().equals("")) {

                        db = mdb.getWritableDatabase();
                        ContentValues values = new ContentValues();
                        values.put("year", year);
                        values.put("month", month);
                        values.put("day", day);
                        values.put("hour", hour);
                        values.put("minute", minute);
                        values.put("title", event_title.getText().toString());
                        values.put("content", event_content.getText().toString());
                        values.put("imgUri", imgName);

                        int row = db.update("event", values, "id=?", new String[]{flag + ""});
                        if (row > 0) {
                            builder.setIcon(R.drawable.ic_baseline_check_24)
                                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            finish();
                                        }
                                    }).setMessage("编辑成功！").setTitle("提示").show();
                        } else {
                            builder.setIcon(R.drawable.ic_baseline_warning_24).setMessage("编辑失败，请重试！").setTitle("提示").show();

                        }
                    }else {
                        builder.setMessage("请输入标题").setTitle("提示").show();

                    }
                }
            }
        });

        // 时间选择器按钮
        timePickerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View v = getLayoutInflater().inflate(R.layout.time_picker, null);

                Button btn_no = v.findViewById(R.id.n);
                Button btn_y  = v.findViewById(R.id.y);
                timePicker = v.findViewById(R.id.timePicker);
                datePicker = v.findViewById(R.id.datePicker);

                timePicker.setIs24HourView(true);

                LocalDateTime now = LocalDateTime.now();
                int hour = now.getHour();
                int minute = now.getMinute();

                timePicker.setHour(hour);
                timePicker.setMinute(minute);

                btn_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        timePickWindow.dismiss();
                    }
                });

                btn_y.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        year = datePicker.getYear();
                        month= datePicker.getMonth() + 1;
                        day = datePicker.getDayOfMonth();

                        EditActivity.this.hour = timePicker.getHour();
                        EditActivity.this.minute = timePicker.getMinute();

                        Toast.makeText(EditActivity.this, "选择的时间："+year+"年"+month+"月"+day+"日"+ EditActivity.this.hour +"时"+ EditActivity.this.minute +"分", Toast.LENGTH_SHORT).show();
                        event_time.setText(""+year+"年"+month+"月"+day+"日"+ EditActivity.this.hour +"时"+ EditActivity.this.minute +"分");
                        timePickWindow.dismiss();
                    }
                });

                timePickWindow = new PopupWindow(v,1000, ViewGroup.LayoutParams.WRAP_CONTENT);
                timePickWindow.setOutsideTouchable(true);
                timePickWindow.setFocusable(true);
                timePickWindow.showAsDropDown(event_time,0,10);

            }
        });

        // 时间显示文本点击事件
        event_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View v = getLayoutInflater().inflate(R.layout.time_picker, null);

                Button btn_no = v.findViewById(R.id.n);
                Button btn_y  = v.findViewById(R.id.y);
                timePicker = v.findViewById(R.id.timePicker);
                datePicker = v.findViewById(R.id.datePicker);

                timePicker.setIs24HourView(true);


                btn_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        timePickWindow.dismiss();
                    }
                });

                btn_y.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        year = datePicker.getYear();
                        month= datePicker.getMonth() + 1;
                        day = datePicker.getDayOfMonth();

                        hour = timePicker.getHour();
                        minute = timePicker.getMinute();

                        Toast.makeText(EditActivity.this, "选择的时间："+year+"年"+month+"月"+day+"日"+hour+"时"+minute+"分", Toast.LENGTH_SHORT).show();
                        event_time.setText(""+year+"年"+month+"月"+day+"日"+hour+"时"+minute+"分");
                        timePickWindow.dismiss();
                    }
                });

                timePickWindow = new PopupWindow(v,1000, ViewGroup.LayoutParams.WRAP_CONTENT);
                timePickWindow.setOutsideTouchable(true);
                timePickWindow.setFocusable(true);
                timePickWindow.showAsDropDown(event_time,0,10);

            }
        });

        // 调用相机拍照按钮
        event_photo_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePhoto();
            }
        });

        /*File testFile = new File("/storage/emulated/0/Android/data/com.example.todolist/cache/7d300fb4-f9ce-4d4b-a891-16003cda812f.jpeg");
        imgUri = FileProvider.getUriForFile(this, "com.todolist.fileProvider", testFile);
        try {
            InputStream inputStream =getContentResolver().openInputStream(imgUri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            event_img.setImageBitmap(bitmap);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }*/


    }

    private void initActivity() {
        db = mdb.getReadableDatabase();

        Cursor cursor = db.rawQuery("select * from event where id=?", new String[]{flag + ""});

        cursor.moveToFirst();
        @SuppressLint("Range") EventData eventData = new EventData(cursor.getInt(cursor.getColumnIndex("id")),
                cursor.getInt(cursor.getColumnIndex("year")),
                cursor.getInt(cursor.getColumnIndex("month")),
                cursor.getInt(cursor.getColumnIndex("day")),
                cursor.getInt(cursor.getColumnIndex("hour")),
                cursor.getInt(cursor.getColumnIndex("minute")),
                cursor.getString(cursor.getColumnIndex("title")),
                cursor.getString(cursor.getColumnIndex("content")),
                cursor.getString(cursor.getColumnIndex("finished")),
                cursor.getString(cursor.getColumnIndex("imgUri")));

        cursor.close();

        year = eventData.getYear();
        month= eventData.getMonth();
        day = eventData.getDay();

        hour = eventData.getHour();
        minute = eventData.getMinuet();

//        Toast.makeText(EditActivity.this, "选择的时间："+year+"年"+month+"月"+day+"日"+hour+"时"+minute+"分", Toast.LENGTH_SHORT).show();
        event_time.setText(""+year+"年"+month+"月"+day+"日"+hour+"时"+minute+"分");
        event_title.setText(eventData.getTitle());
        event_content.setText(eventData.getContent());
        imgName = eventData.getImgUri();

        if(!imgName.equals("")) {
            File testFile = new File(URI + imgName);
            imgUri = FileProvider.getUriForFile(
                    this, "com.todolist.fileProvider", testFile);
            try {
                InputStream inputStream = getContentResolver().openInputStream(imgUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                event_img.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

    }

    private void updateLocale() {
        try {
            Locale locale = getResources().getConfiguration().locale;
            if (locale == Locale.SIMPLIFIED_CHINESE) {  //常量比较
                return;
            }
            Resources resources = getResources();
            Configuration configuration = resources.getConfiguration();
            Locale.setDefault(Locale.SIMPLIFIED_CHINESE);
            if (Build.VERSION.SDK_INT >= 24) {
                configuration.setLocales(new LocaleList(Locale.SIMPLIFIED_CHINESE));
            } else if (Build.VERSION.SDK_INT >= 17) {
                configuration.setLocale(Locale.SIMPLIFIED_CHINESE);
            } else {
                configuration.locale = Locale.SIMPLIFIED_CHINESE;
            }
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }


    /**
     * 拍照
     */
    public void takePhoto(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
            // 拥有权限 执行拍照
            doTake();
        }else {
            // 没有权限 去申请权限
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},1);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 1){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                doTake();
            }else {
                Toast.makeText(this, "没有相机权限", Toast.LENGTH_SHORT).show();

            }
        }

    }

    private void doTake() {
        String uuid = UUID.randomUUID().toString();
        imgName = uuid + ".jpeg";
        File imageTemp = new File(getExternalCacheDir(), imgName);

        if (imageTemp.exists()) {
            imageTemp.delete();
        }

        try {
            imageTemp.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (Build.VERSION.SDK_INT > 24) {
            // contentProvider
            imgUri = FileProvider.getUriForFile(this, "com.todolist.fileProvider", imageTemp);
        } else {
            imgUri = Uri.fromFile(imageTemp);
        }

        Intent intent = new Intent();
        intent.setAction("android.media.action.IMAGE_CAPTURE");
        intent.putExtra(MediaStore.EXTRA_OUTPUT,imgUri);

        startActivityForResult(intent,1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                InputStream inputStream = null;
                try {
                    inputStream = getContentResolver().openInputStream(imgUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    event_img.setImageBitmap(bitmap);
//                    URI += imgName;
//                    String imageToBase64 = ImageUtil.imageToBase64(bitmap);
//                    imageBase64 = imageToBase64;
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }
        }

    }
}