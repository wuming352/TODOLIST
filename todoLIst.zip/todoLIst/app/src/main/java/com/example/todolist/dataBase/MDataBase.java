package com.example.todolist.dataBase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MDataBase extends SQLiteOpenHelper {

    private String sql = "create table event(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "year INTEGER," +
            "month INTEGER," +
            "day INTEGER," +
            "hour INTEGER," +
            "minute INTEGER," +
            "title TEXT," +
            "content TEXT," +
            "finished VARCHAR(1)," +
            "imgUri TEXT" +
            ")";

    private String sql1 = "create table acount(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "year INTEGER," +
            "month INTEGER," +
            "day INTEGER," +
            "unfinish INTEGER," +
            "finish INTEGER," +
            "overdue INTEGER," +
            "cancel INTEGER" +
            ")";

    public MDataBase(@Nullable Context context, int version) {
        super(context, "event.db", null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(sql);
        sqLiteDatabase.execSQL(sql1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
