package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.todolist.dataBase.MDataBase;
import com.example.todolist.entity.Account;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AccountActivity extends AppCompatActivity {

    private PieChart pie_chart;
    private ImageButton startDateBtn;
    private ImageButton endDateBtn;
    private TextView startDate;
    private TextView endDate;

    private DatePicker datePicker;
    private PopupWindow timePickWindow; // 时间选择弹窗

    private int startYear;
    private int startMonth;
    private int startDay;

    private int endYear;
    private int endMonth;
    private int endDay;

    private MDataBase mDataBase;
    private SQLiteDatabase db;

    //TODO 添加选项的文字
    ArrayList<PieEntry> entries = new ArrayList<PieEntry>();
    //TODO 添加选项的颜色
    ArrayList<Integer> colors = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        updateLocale();

        pie_chart = findViewById(R.id.chart);

        startDate = findViewById(R.id.start_date);
        endDate = findViewById(R.id.end_date);

        startDateBtn = findViewById(R.id.start_date_btn);
        endDateBtn = findViewById(R.id.end_date_btn);

        LocalDateTime now = LocalDateTime.now();
        startYear = now.getYear();
        startMonth = now.getMonthValue();
        startDay = LocalDateTime.MIN.getDayOfMonth();

        endYear = now.getYear();
        endMonth = now.getMonthValue();
        endDay = LocalDateTime.MAX.getDayOfMonth();

        startDate.setText(startYear + "年" + startMonth + "月" + startDay + "日");
        endDate.setText(endYear + "年" + endMonth + "月" + endDay + "日");


        setDgcChart();
        initBtn();
        accountData();


    }

    private void initBtn() {
        startDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View v = getLayoutInflater().inflate(R.layout.date_picker, null);

                Button btn_no = v.findViewById(R.id.n);
                Button btn_y = v.findViewById(R.id.y);
                datePicker = v.findViewById(R.id.datePicker);


                btn_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        timePickWindow.dismiss();
                    }
                });

                btn_y.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startYear = datePicker.getYear();
                        startMonth = datePicker.getMonth() + 1;
                        startDay = datePicker.getDayOfMonth();

                        if(startYear > endYear){
                            Toast.makeText(AccountActivity.this, "日期选择有误,请重新选择！", Toast.LENGTH_SHORT).show();
                        }else if(startYear == endYear && startMonth > endMonth){
                            Toast.makeText(AccountActivity.this, "日期选择有误,请重新选择！", Toast.LENGTH_SHORT).show();
                        }else if(startMonth == endMonth && startDay > endDay){
                            Toast.makeText(AccountActivity.this, "日期选择有误,请重新选择！", Toast.LENGTH_SHORT).show();
                        }else {

                            startDate.setText("" + startYear + "年" + startMonth + "月" + startDay + "日");
                            accountData();
                        }
                        timePickWindow.dismiss();
                    }
                });

                timePickWindow = new PopupWindow(v, 800, ViewGroup.LayoutParams.WRAP_CONTENT);
                timePickWindow.setOutsideTouchable(true);
                timePickWindow.setFocusable(true);
                timePickWindow.showAsDropDown(startDate, 0, 10);
            }
        });

        endDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View v = getLayoutInflater().inflate(R.layout.date_picker, null);

                Button btn_no = v.findViewById(R.id.n);
                Button btn_y = v.findViewById(R.id.y);
                datePicker = v.findViewById(R.id.datePicker);


                btn_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        timePickWindow.dismiss();
                    }
                });

                btn_y.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        endYear = datePicker.getYear();
                        endMonth = datePicker.getMonth() + 1;
                        endDay = datePicker.getDayOfMonth();

                        if(endYear < startYear){
                            Toast.makeText(AccountActivity.this, "日期选择有误,请重新选择！", Toast.LENGTH_SHORT).show();
                        }else if(endYear == startYear && endMonth < startMonth){
                            Toast.makeText(AccountActivity.this, "日期选择有误,请重新选择！", Toast.LENGTH_SHORT).show();
                        }else if(endMonth == startMonth && endDay < startDay){
                            Toast.makeText(AccountActivity.this, "日期选择有误,请重新选择！", Toast.LENGTH_SHORT).show();
                        }else{
                            endDate.setText("" + endYear + "年" + endMonth + "月" + endDay + "日");
                            accountData();
                        }

                        timePickWindow.dismiss();
                    }
                });

                timePickWindow = new PopupWindow(v, 800, ViewGroup.LayoutParams.WRAP_CONTENT);
                timePickWindow.setOutsideTouchable(true);
                timePickWindow.setFocusable(true);
                timePickWindow.showAsDropDown(endDate, 0, 10);
            }
        });


    }

    @SuppressLint("Range")
    private void accountData() {
        int finishAccount = 0;
        int overdueAccount = 0;
        int cancelAccount = 0;
        int unfinishedAccount = 0;
        List<Account> accountList = new ArrayList<>();
        mDataBase = new MDataBase(this, 1);
        db = mDataBase.getReadableDatabase();
        Cursor cursor = null;

        if (startYear == endYear) {
            if (startMonth == endMonth) {
                if (startDay == endDay) {

                    cursor = db.rawQuery("select sum(finish),sum(overdue),sum(cancel),sum(unfinish) from acount where year = ? and month = ? and day = ?",
                            new String[]{startYear+"",startMonth+"",startDay+""});
                    cursor.moveToFirst();

                    finishAccount = cursor.getInt(cursor.getColumnIndex("sum(finish)"));
                    overdueAccount = cursor.getInt(cursor.getColumnIndex("sum(overdue)"));
                    cancelAccount = cursor.getInt(cursor.getColumnIndex("sum(cancel)"));
                    unfinishedAccount = cursor.getInt(cursor.getColumnIndex("sum(unfinish)"));

                } else if (startDay < endDay) {

                    cursor = db.rawQuery("select sum(finish),sum(overdue),sum(cancel),sum(unfinish) from acount where year = ? and month = ? and day between ? and ? ",
                            new String[]{startYear+"",startMonth+"",startDay+"",endDay+""});
                    cursor.moveToFirst();

                    finishAccount = cursor.getInt(cursor.getColumnIndex("sum(finish)"));
                    overdueAccount = cursor.getInt(cursor.getColumnIndex("sum(overdue)"));
                    cancelAccount = cursor.getInt(cursor.getColumnIndex("sum(cancel)"));
                    unfinishedAccount = cursor.getInt(cursor.getColumnIndex("sum(unfinish)"));


                }

            } else if (startMonth < endMonth) {

                cursor = db.rawQuery("select * from acount where year = ? and month between ? and ? ",
                        new String[]{startYear+"",startMonth+"",endMonth+""});
                cursor.moveToFirst();

                while(!cursor.isAfterLast()){
                    int day = cursor.getInt(cursor.getColumnIndex("day"));
                    int month = cursor.getInt(cursor.getColumnIndex("month"));

                    if(month*100+day <= endMonth*100+endDay && month*100+day >= startMonth*100+startDay){
                        finishAccount += cursor.getInt(cursor.getColumnIndex("finish"));
                        overdueAccount += cursor.getInt(cursor.getColumnIndex("overdue"));
                        cancelAccount += cursor.getInt(cursor.getColumnIndex("cancel"));
                        unfinishedAccount += cursor.getInt(cursor.getColumnIndex("unfinish"));
                    }
                    cursor.moveToNext();
                }


            }

        } else if (startYear < endYear) {
            cursor = db.rawQuery("select * from acount where year between ? and ?",new String[]{startYear+"",endYear+""});
            cursor.moveToFirst();

            while (!cursor.isAfterLast()){
                int year = cursor.getInt(cursor.getColumnIndex("year"));
                int month = cursor.getInt(cursor.getColumnIndex("month"));
                int day = cursor.getInt(cursor.getColumnIndex("day"));

                if(year*1000+month*100+day <= endYear*1000+endMonth*100+endDay && year*1000+month*100+day >= startYear*1000+startMonth*100+startDay){

                    finishAccount += cursor.getInt(cursor.getColumnIndex("finish"));
                    overdueAccount += cursor.getInt(cursor.getColumnIndex("overdue"));
                    cancelAccount += cursor.getInt(cursor.getColumnIndex("cancel"));
                    unfinishedAccount += cursor.getInt(cursor.getColumnIndex("unfinish"));

                }
                cursor.moveToNext();
            }

        }

        cursor.close();

//        cursor = db.rawQuery("select count(finish),count(overdue),count(cancel) from acount where year = ?", new String[]{"2022"});
//        cursor.moveToFirst();

//        int finishAccount = cursor.getInt(cursor.getColumnIndex("count(finish)"));
//        int overdueAccount = cursor.getInt(cursor.getColumnIndex("count(overdue)"));
//        int cancelAccount = cursor.getInt(cursor.getColumnIndex("count(cancel)"));

        entries.clear();
        entries.add(new PieEntry(unfinishedAccount, "未完成"));
        entries.add(new PieEntry(finishAccount, "完成"));
        entries.add(new PieEntry(overdueAccount, "逾期"));
        entries.add(new PieEntry(cancelAccount, "取消"));

        setDgcChart();
    }


    public void setDgcChart() {
        //TODO 设置饼图还是环形图
        pie_chart.setDrawHoleEnabled(false);
        //TODO 设置显示的数值是占百分比还是直接显示数值
        pie_chart.setUsePercentValues(false);
        //TODO 如果设置为true 组件内容不可删除
        pie_chart.getDescription().setEnabled(false);
        //TODO 设置附加到自动计算的偏移的额外偏移（在图表视图周围）。
        pie_chart.setExtraOffsets(0.f, 50.f, 0.f, 80.f);
        //TODO 减速摩擦系数在[0；1]区间内，数值越大表示速度会缓慢下降，例如，如果设定为0，则会立即停止。1是无效值，将自动转换为0.999f。
        pie_chart.setDragDecelerationFrictionCoef(0.5f);
        //TODO 设置环形图中间孔的空白的背景颜色
        pie_chart.setHoleColor(Color.WHITE); //中间圆颜色
        //TODO 设置环形图中间的空白和环形图之间的浅色区域
        pie_chart.setTransparentCircleColor(Color.WHITE);
        //TODO 设置中间隔开区域的透明度
        pie_chart.setTransparentCircleAlpha(110);
        //TODO 设置环形图中间空白区域的大小（半径）
        pie_chart.setHoleRadius(30f);  //圆半径
        //TODO 设置中间浅色区域的大小
        pie_chart.setTransparentCircleRadius(44f);
        pie_chart.setDrawCenterText(true);
        pie_chart.setRotationAngle(-90);
        //TODO 设置是否可以旋转
        pie_chart.setRotationEnabled(false);
        //TODO 是否可以点击
        pie_chart.setHighlightPerTapEnabled(true);
        //TODO 触摸监听
        pie_chart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry entry, Highlight highlight) {
                Log.e("*************", "开启");
                if (highlight.getX() == 0) {
                    Toast.makeText(AccountActivity.this, "" + entries.get(0).getLabel(), Toast.LENGTH_SHORT).show();
                } else if (highlight.getX() == 1.0) {
                    Toast.makeText(AccountActivity.this, "" + entries.get(1).getValue(), Toast.LENGTH_SHORT).show();
                } else if (highlight.getX() == 2.0) {
                    Toast.makeText(AccountActivity.this, "" + entries.get(2).toString(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected() {
                Log.e("*************", "关闭");

            }
        });

        //((PieHolder) holder).pie_chart.setEntryLabelColor(mContext.getResources().getColor(R.color.red_main)); //设置饼图标签颜色
        //TODO 添加数据
        setPieData(pie_chart);
        //TODO 设置加载数据的动画
        pie_chart.animateY(1200, Easing.EasingOption.EaseInOutQuad); //设置饼图动画
        pie_chart.setDrawEntryLabels(!pie_chart.isDrawEntryLabelsEnabled());

        Legend l = pie_chart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setTextSize(15f);
        l.setDrawInside(true);
        l.setTextColor(Color.BLUE);
        l.setEnabled(true);
    }

    /**
     * 设置饼图数据
     */
    private void setPieData(PieChart chart) {

        colors.add(Color.parseColor("#FFDE00")); //未完成
        colors.add(Color.parseColor("#00F30A")); //完成
        colors.add(Color.parseColor("#FF0000")); //逾期
        colors.add(Color.parseColor("#656565")); //取消

        PieDataSet dataSet = new PieDataSet(entries,"");
        //TODO 不同块之间的间距
        dataSet.setSliceSpace(0f);
        //TODO 选中时候突出的间距
        dataSet.setSelectionShift(0f);
        //TODO 设置选项的颜色
        dataSet.setColors(colors);
        //TODO 设置饼图内的指示线的位置（是靠近内环还是靠近外环）
        dataSet.setValueLinePart1OffsetPercentage(100f);
        //TODO 设置指向饼图的指示线的长度1
        dataSet.setValueLinePart1Length(0.7f);
        //TODO 设置指向文字的指示线的长度2
        dataSet.setValueLinePart2Length(0.0f);
        dataSet.setHighlightEnabled(true);
        //TODO 设置指示线的粗细
        dataSet.setValueLineWidth(2f);
        //TODO 设置提示文字在图外还是图内
        dataSet.setYValuePosition(PieDataSet.ValuePosition.INSIDE_SLICE);
        //TODO 设置指示线条颜色,必须设置成这样，才能和饼图区域颜色一致
        dataSet.setValueLineColor(0xff000000);
        //TODO 设置提示文字的颜色
        dataSet.setValueTextColor(Color.BLACK);
        PieData data = new PieData(dataSet);
//        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(20f);
        data.setHighlightEnabled(true);

        chart.setData(data);
        chart.highlightValues(null);
        chart.invalidate();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_option, menu);

        return true;
    }

    /**
     * 菜单项目点击事件
     *
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId(); //获取菜单项id

        switch (itemId) {
            case R.id.menu_change:
                Toast.makeText(this, "切换视图", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, ListActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_statistic:
                Toast.makeText(this, "统计", Toast.LENGTH_SHORT).show();
                return true;
        }


        return true;
    }

    private void updateLocale() {
        try {
            Locale locale = getResources().getConfiguration().locale;
            if (locale == Locale.SIMPLIFIED_CHINESE) {  //常量比较
                return;
            }
            Resources resources = getResources();
            Configuration configuration = resources.getConfiguration();
            Locale.setDefault(Locale.SIMPLIFIED_CHINESE);
            if (Build.VERSION.SDK_INT >= 24) {
                configuration.setLocales(new LocaleList(Locale.SIMPLIFIED_CHINESE));
            } else if (Build.VERSION.SDK_INT >= 17) {
                configuration.setLocale(Locale.SIMPLIFIED_CHINESE);
            } else {
                configuration.locale = Locale.SIMPLIFIED_CHINESE;
            }
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

}