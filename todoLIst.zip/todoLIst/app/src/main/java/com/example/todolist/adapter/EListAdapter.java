package com.example.todolist.adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.todolist.EditActivity;
import com.example.todolist.R;
import com.example.todolist.dataBase.MDataBase;
import com.example.todolist.entity.Event;
import com.example.todolist.entity.EventData;

import java.util.List;

public class EListAdapter extends BaseAdapter implements View.OnClickListener, View.OnLongClickListener {

    private List<EventData> eventDataList;
    private LayoutInflater inflater;
    private Context context;

    private MDataBase mDataBase;
    private SQLiteDatabase db;

    private MClickListener mClickListener;
    private MLongClickListener mLongClickListener;
    private DetailClickListener detailClickListener;

    public interface MLongClickListener{
        void longClickListener(View view);
    }

    public interface MClickListener{
        void clickListener(View view);
    }

    public interface DetailClickListener{
        void detailClickListener(View view);
    }

    public EListAdapter(List<EventData> list, Context context, MClickListener listener,MLongClickListener mLongClickListener,DetailClickListener detailClickListener){

        this.eventDataList = list;
        this.context = context;
        this.mClickListener = listener;
        this.mLongClickListener = mLongClickListener;
        this.detailClickListener = detailClickListener;

        mDataBase = new MDataBase(context,1);
        inflater = LayoutInflater.from(context);
    }


    @Override
    public int getCount() {
        return eventDataList.size();
    }

    @Override
    public EventData getItem(int i) {
        return eventDataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if(convertView == null){
            convertView = inflater.inflate(R.layout.event_list_item, null);
            viewHolder = new ViewHolder();
            viewHolder.date = (TextView)convertView.findViewById(R.id.list_event_date);
            viewHolder.title = (TextView)convertView.findViewById(R.id.list_event_title);
            viewHolder.time =  convertView.findViewById(R.id.list_event_time);
            viewHolder.checkBox = convertView.findViewById(R.id.list_event_check);
            viewHolder.delete = convertView.findViewById(R.id.list_event_delete);
            viewHolder.list_layout = convertView.findViewById(R.id.list_layout);
//            viewHolder.condition = convertView.findViewById(R.id.condition);

            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder)convertView.getTag();
        }

        EventData data = eventDataList.get(position);
        String hourText = data.getHour()+"";
        String minuteText = data.getMinuet()+"";
        String monthText = data.getMonth()+"";
        String dayText = data.getDay()+"";
        String yearText = data.getYear()+"";
        if(data.getHour() < 10){
            hourText = "0"+hourText;
        }
        if(data.getMinuet() < 10){
            minuteText = "0"+minuteText;
        }
        if(data.getMonth() < 10){
            monthText = "0"+monthText;
        }
        if(data.getDay() < 10){
            dayText = "0"+dayText;
        }

        viewHolder.time.setText(hourText+":"+minuteText);
        viewHolder.date.setText(yearText+"/"+monthText+"/"+dayText);
        viewHolder.title.setText(data.getTitle());

        if(getItem(position).getFinished().equals("0")){
            viewHolder.checkBox.setChecked(false);
            viewHolder.checkBox.setClickable(true);
            viewHolder.list_layout.setBackgroundResource(R.color.teal_200);
            viewHolder.delete.setBackgroundResource(R.drawable.ic_baseline_close_24);
//            viewHolder.checkBox.setClickable(false);
        }else if (getItem(position).getFinished().equals("1")){
            viewHolder.checkBox.setChecked(true);
            viewHolder.checkBox.setClickable(true);
            viewHolder.list_layout.setBackgroundResource(R.color.itemBackground);
            viewHolder.delete.setBackgroundResource(R.drawable.ic_baseline_close_24);
        }else{
            viewHolder.checkBox.setClickable(false);
            viewHolder.list_layout.setBackgroundResource(R.color.negative);
            viewHolder.delete.setBackgroundResource(R.drawable.ic_baseline_close_24_black);

        }

        viewHolder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @SuppressLint("Range")
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                db = mDataBase.getWritableDatabase();
                int id = getItem(position).getId();
                int year = getItem(position).getYear();
                int month = getItem(position).getMonth();
                int day = getItem(position).getDay();

                if(isChecked){
//                    Toast.makeText(context, "选中", Toast.LENGTH_SHORT).show();

                    ContentValues values = new ContentValues();
                    values.put("finished", "1");
                    int row = db.update("event", values, "id=?", new String[]{id + ""});
                    if(row > 0){
                        Toast.makeText(context, "事件完成成功", Toast.LENGTH_SHORT).show();
                        db = mDataBase.getReadableDatabase();
                        Cursor cursor = db.rawQuery("select * from acount where year = ? and" +
                                " month = ? and day = ?", new String[]{year + "", month + "", day + ""});
                        cursor.moveToFirst();
                        if(cursor.isAfterLast()){
                            values.clear();
                            values.put("year",year);
                            values.put("month",month);
                            values.put("day",day);
                            values.put("finish",1);

                            db.insert("acount",null,values);
                        }else {
                            values.clear();
                            values.put("finish",cursor.getInt(cursor.getColumnIndex("finish")) + 1);
                            values.put("unfinish",cursor.getInt(cursor.getColumnIndex("unfinish")) - 1);
                            @SuppressLint("Range") int aId = cursor.getInt(cursor.getColumnIndex("id"));
                            db.update("acount",values,"id = ?",new String[]{aId+""});
                        }
                        cursor.close();

                    }else {
                        Toast.makeText(context, "完成事件失败", Toast.LENGTH_SHORT).show();
                    }

                }else {
//                    Toast.makeText(context, "取消选中", Toast.LENGTH_SHORT).show();
                    ContentValues values = new ContentValues();
                    values.put("finished", "0");
                    int row = db.update("event", values, "id=?", new String[]{id + ""});
                    if(row > 0){
                        Toast.makeText(context, "取消事件完成成功", Toast.LENGTH_SHORT).show();

                        db = mDataBase.getReadableDatabase();
                        Cursor cursor = db.rawQuery("select * from acount where year = ? and month = ? and day = ?", new String[]{year + "", month + "", day + ""});
                        cursor.moveToFirst();
                        if(cursor.isAfterLast()){
                            values.clear();
                            values.put("year",year);
                            values.put("month",month);
                            values.put("day",day);
                            values.put("finish",0);

                            db.insert("acount",null,values);
                        }else {
                            values.clear();
                            values.put("finish",cursor.getInt(cursor.getColumnIndex("finish") )- 1);
                            values.put("unfinish",cursor.getInt(cursor.getColumnIndex("unfinish")) + 1);
                            @SuppressLint("Range") int aId = cursor.getInt(cursor.getColumnIndex("id"));
                            db.update("acount",values,"id = ?",new String[]{aId+""});
                        }
                        cursor.close();

                    }else {
                        Toast.makeText(context, "取消 完成事件失败", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        viewHolder.delete.setOnClickListener(this);
        viewHolder.delete.setTag(position);

        /*viewHolder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setIcon(R.drawable.ic_baseline_warning_24_yellow).setTitle("提示").setMessage("是否删除改事项")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(context, "确定", Toast.LENGTH_SHORT).show();

                                db = mDataBase.getWritableDatabase();
                                int id = getItem(position).getId();
                                int row = db.delete("event", "id=?", new String[]{id + ""});
                                if(row > 0){
                                    Toast.makeText(context, "删除成功", Toast.LENGTH_SHORT).show();
                                }else {
                                    Toast.makeText(context, "删除失败", Toast.LENGTH_SHORT).show();
                                }

                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(context, "取消", Toast.LENGTH_SHORT).show();
                            }
                        }).show();
            }
        });*/



        if(!getItem(position).getFinished().equals("2")) {
            viewHolder.title.setOnLongClickListener(this);
        }
        viewHolder.title.setTag(position);
        viewHolder.title.setOnClickListener(this);


        return convertView;

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.list_event_delete:
                mClickListener.clickListener(view);
                break;
            case R.id.list_event_title:
                detailClickListener.detailClickListener(view);
                break;
        }
    }

    @Override
    public boolean onLongClick(View view) {
        mLongClickListener.longClickListener(view);
        return true;
    }

    class ViewHolder{
        TextView time;
        TextView date;
        TextView title;
        CheckBox checkBox;
        ImageButton delete;
        LinearLayout list_layout;
    }
}
